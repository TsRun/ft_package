The ft_package is a package manager for the 42 school projects. It is
designed to be used with the 42 school projects, but it can be used for
other projects as well.
